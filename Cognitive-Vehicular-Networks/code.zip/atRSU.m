function [y]=atRSU(toRSU)
%AT RSU
 data=fskdemodulation(toRSU);
 %Q=vertcat(Q,data);
 if(data[1]==1)
     x=0;
     
 else
 %numero=numero+1;
 %xlswrite('data6.xlsx',data,'section II',['A' num2str(numero)]);
 writetable(data,'data6.xlsx','WriteMode','Append','WriteVariableNames',false,'WriteRowNames',true);
 
 end
 y=1;
end